import { DotNetRuTemplatePage } from './app.po';

describe('DotNetRu App', function() {
  let page: DotNetRuTemplatePage;

  beforeEach(() => {
    page = new DotNetRuTemplatePage();
  });

  it('should display message saying app works', () => {
    page.navigateTo();
    expect(page.getParagraphText()).toEqual('app works!');
  });
});

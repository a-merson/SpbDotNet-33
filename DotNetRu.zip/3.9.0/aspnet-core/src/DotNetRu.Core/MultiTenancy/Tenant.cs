﻿using Abp.MultiTenancy;
using DotNetRu.Authorization.Users;

namespace DotNetRu.MultiTenancy
{
    public class Tenant : AbpTenant<User>
    {
        public Tenant()
        {            
        }

        public Tenant(string tenancyName, string name)
            : base(tenancyName, name)
        {
        }
    }
}

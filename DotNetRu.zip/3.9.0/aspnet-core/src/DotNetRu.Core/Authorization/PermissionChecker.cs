﻿using Abp.Authorization;
using DotNetRu.Authorization.Roles;
using DotNetRu.Authorization.Users;

namespace DotNetRu.Authorization
{
    public class PermissionChecker : PermissionChecker<Role, User>
    {
        public PermissionChecker(UserManager userManager)
            : base(userManager)
        {
        }
    }
}

﻿namespace DotNetRu
{
    public class DotNetRuConsts
    {
        public const string LocalizationSourceName = "DotNetRu";

        public const string ConnectionStringName = "Default";

        public const bool MultiTenancyEnabled = true;
    }
}

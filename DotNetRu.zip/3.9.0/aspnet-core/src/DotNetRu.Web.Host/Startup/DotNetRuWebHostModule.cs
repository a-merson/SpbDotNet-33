﻿using Microsoft.AspNetCore.Hosting;
using Microsoft.Extensions.Configuration;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DotNetRu.Configuration;

namespace DotNetRu.Web.Host.Startup
{
    [DependsOn(
       typeof(DotNetRuWebCoreModule))]
    public class DotNetRuWebHostModule: AbpModule
    {
        private readonly IHostingEnvironment _env;
        private readonly IConfigurationRoot _appConfiguration;

        public DotNetRuWebHostModule(IHostingEnvironment env)
        {
            _env = env;
            _appConfiguration = env.GetAppConfiguration();
        }

        public override void Initialize()
        {
            IocManager.RegisterAssemblyByConvention(typeof(DotNetRuWebHostModule).GetAssembly());
        }
    }
}

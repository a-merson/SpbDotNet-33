using System.ComponentModel.DataAnnotations;

namespace DotNetRu.Users.Dto
{
    public class ChangeUserLanguageDto
    {
        [Required]
        public string LanguageName { get; set; }
    }
}
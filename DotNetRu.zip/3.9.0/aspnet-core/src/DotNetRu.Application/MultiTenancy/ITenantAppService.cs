﻿using Abp.Application.Services;
using Abp.Application.Services.Dto;
using DotNetRu.MultiTenancy.Dto;

namespace DotNetRu.MultiTenancy
{
    public interface ITenantAppService : IAsyncCrudAppService<TenantDto, int, PagedResultRequestDto, CreateTenantDto, TenantDto>
    {
    }
}

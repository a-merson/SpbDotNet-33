﻿using System.Threading.Tasks;
using DotNetRu.Configuration.Dto;

namespace DotNetRu.Configuration
{
    public interface IConfigurationAppService
    {
        Task ChangeUiTheme(ChangeUiThemeInput input);
    }
}

﻿using Abp.AutoMapper;
using Abp.Modules;
using Abp.Reflection.Extensions;
using DotNetRu.Authorization;

namespace DotNetRu
{
    [DependsOn(
        typeof(DotNetRuCoreModule), 
        typeof(AbpAutoMapperModule))]
    public class DotNetRuApplicationModule : AbpModule
    {
        public override void PreInitialize()
        {
            Configuration.Authorization.Providers.Add<DotNetRuAuthorizationProvider>();
        }

        public override void Initialize()
        {
            var thisAssembly = typeof(DotNetRuApplicationModule).GetAssembly();

            IocManager.RegisterAssemblyByConvention(thisAssembly);

            Configuration.Modules.AbpAutoMapper().Configurators.Add(
                // Scan the assembly for classes which inherit from AutoMapper.Profile
                cfg => cfg.AddProfiles(thisAssembly)
            );
        }
    }
}

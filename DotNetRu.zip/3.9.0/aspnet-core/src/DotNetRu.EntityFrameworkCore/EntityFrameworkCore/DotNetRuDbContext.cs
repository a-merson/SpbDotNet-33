﻿using Microsoft.EntityFrameworkCore;
using Abp.Zero.EntityFrameworkCore;
using DotNetRu.Authorization.Roles;
using DotNetRu.Authorization.Users;
using DotNetRu.MultiTenancy;

namespace DotNetRu.EntityFrameworkCore
{
    public class DotNetRuDbContext : AbpZeroDbContext<Tenant, Role, User, DotNetRuDbContext>
    {
        /* Define a DbSet for each entity of the application */
        
        public DotNetRuDbContext(DbContextOptions<DotNetRuDbContext> options)
            : base(options)
        {
        }
    }
}

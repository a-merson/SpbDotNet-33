﻿using Microsoft.EntityFrameworkCore;
using Microsoft.EntityFrameworkCore.Design;
using Microsoft.Extensions.Configuration;
using DotNetRu.Configuration;
using DotNetRu.Web;

namespace DotNetRu.EntityFrameworkCore
{
    /* This class is needed to run "dotnet ef ..." commands from command line on development. Not used anywhere else */
    public class DotNetRuDbContextFactory : IDesignTimeDbContextFactory<DotNetRuDbContext>
    {
        public DotNetRuDbContext CreateDbContext(string[] args)
        {
            var builder = new DbContextOptionsBuilder<DotNetRuDbContext>();
            var configuration = AppConfigurations.Get(WebContentDirectoryFinder.CalculateContentRootFolder());

            DotNetRuDbContextConfigurer.Configure(builder, configuration.GetConnectionString(DotNetRuConsts.ConnectionStringName));

            return new DotNetRuDbContext(builder.Options);
        }
    }
}

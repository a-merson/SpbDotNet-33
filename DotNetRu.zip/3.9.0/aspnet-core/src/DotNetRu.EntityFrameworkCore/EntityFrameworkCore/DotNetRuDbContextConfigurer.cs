using System.Data.Common;
using Microsoft.EntityFrameworkCore;

namespace DotNetRu.EntityFrameworkCore
{
    public static class DotNetRuDbContextConfigurer
    {
        public static void Configure(DbContextOptionsBuilder<DotNetRuDbContext> builder, string connectionString)
        {
            builder.UseSqlServer(connectionString);
        }

        public static void Configure(DbContextOptionsBuilder<DotNetRuDbContext> builder, DbConnection connection)
        {
            builder.UseSqlServer(connection);
        }
    }
}
